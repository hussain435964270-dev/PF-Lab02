#include <stdio.h>
int main(){
float PF = 88.0;
float CAG = 76.5;
float AP = 82.0;
int X = 3;
int Y = 3;
int Z = 2;
float A = (PF*X)+(CAG*Y)+(AP*Z);
float B = X+Y+Z;
float C = A/B;
printf("======================= SEMESTER ACADEMIC REPORT ============================\n");
printf("Course        Credit Hours      Obtained Marks\n");
printf("-----------------------------------------------------------------------------\n");
printf("Programming Fund   %d                 %.2f \n" , X,PF);
printf("Calculas           %d                 %.2f \n" , Y,CAG);
printf("Applied Physics    %d                 %.2f  \n" , Z,AP);
printf("-------------------------------------------------------------------------------\n");
printf("Total credits: %f \n" , B);
printf("Weighted Average: %f \n", C);
printf("=================================================================================");
return 0;
} 	