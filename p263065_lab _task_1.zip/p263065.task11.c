#include <stdio.h>
int main(){
int a = 3; 
int b = 4;
int c = 2;
float x = 60.00;
float y = 40.50;
float z = 120.00;
float p = (a*x);
float q = (b*y);
float r = (c*z);
float J = (a*x)+(b*y)+(c*z);
float K = (0.16*J);
float L = (J+K);
printf("========================== FAST CAFETERIA RECEIPT =========================\n");
printf("Item        Qty       Unit Price (PKR)         Subtotal (PKR)\n");
printf("----------------------------------------------------------------------------\n");
printf("Tea          %d          %.2f                     %.2f \n" , a,x,p);
printf("Samosa       %d          %.2f                     %.2f \n" , b,y,q);
printf("Chicken Roll %d          %.2f                    %.2f \n" , c,z,r);
printf("-----------------------------------------------------------------------------\n");
printf("Subtotal: PKR %.2f \n" , J);
printf("GST: PKR %.2f \n" , K);
printf("-------------------------------------------------------------------------------\n");
printf("Grand Total: PKR %.2f \n" , L);
printf("================== THANK YOU FOR YOUR VISIT =====================");
return 0;
}