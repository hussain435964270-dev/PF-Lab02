#include <stdio.h>
int main(){
int Batch = 2026;
char Section =('B');
float Entrytestscore = 50.65;
double Semesterfee = 150000.25;
printf("================================================FAST-NUCES STUDENT PROFILE CARD================================================\n" );
printf("Batch: \t %d \n" , Batch);
printf("Section: \t %c \n" , Section);
printf("Entry test score: \t %f \n", Entrytestscore);
printf("Semester fee: \t %1f \n", Semesterfee);
printf("MOTTO: CHARACTER IS DESTINY");

   return 0;
}
