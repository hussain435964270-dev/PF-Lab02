#include <stdio.h>
int main(){
char b = ('\\');
char c = ('\n');
char d = ('/');
char e = ('%');
printf("================================= C ESCAPE SEQUENCE REFERENCE =======================================\n");
printf("To print a double quote, write:\t %c \n" , b);
printf("To print a literal backslash, write: %c%c \n" , b,b);
printf("To insert a new line, write: %c \n" , c);
printf("To insert a horizontal break, write: %c%c \n" , d);
printf("To print a percentsign, write: %c%c \n" , e,e);
     return 0;
}
