#include <stdio.h>
int main(){
char a = ('Z');
int b = 94;
float c = 3.913;
double d = 77.43;
printf("Type Name  Variable Name  Size in Memory \t \n");
printf("char \t        %c          \t 1 byte(s) \n" , a);
printf("int \t        %d          \t 4 byte(s) \n" , b);
printf("float \t       %f        \t 4 byte(s) \n" , c);
printf("double \t      %f      \t 8 byte(s) \n" , d); 
printf("=======================================================================");
return 0;
}
