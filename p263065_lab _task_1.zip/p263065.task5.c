#include <stdio.h>
int main(){
float Celsius = 37.50;
float Fahrenheit = 99.50;
float Kelvin = 310.65;
float a = (Celsius*9.0/5.0) + 32.0;
float b = Celsius + 273.15;
printf("================ TEMPERATURE CONVERSION ==================\n");
printf("Celsius: %.2f \n" , Celsius);
printf("Fahrenheit: %.2f \n" , Fahrenheit);
printf("Kelvin: %.2f \n" , Kelvin);
printf("==========================================================");
return 0;
}