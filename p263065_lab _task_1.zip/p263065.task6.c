#include <stdio.h>
int main(){
float r = 7.5;  
float pi = 3.14159;
float Diameter = 2*r;
float Circumference = 2*pi*r;
float Area = pi*r*r;
printf("=============== CIRCLE GEOMETRY REPORT ================\n");
printf("Given radius: %.3f \n" , r);
printf("Calaculated Diameter: %.3f \n" , Diameter);
printf("Calculated Circumference: %.3f \n" , Circumference); 
printf("Calculated Area: %.3f \n" , Area);
printf("=========================================================");
   return 0;
}
 