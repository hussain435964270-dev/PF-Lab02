#include <stdio.h>
int main(){
double principal = 250000.00; 
float rate = 8.5; 
int time = 3;
char x = ('%'); 
float si = (principal*rate*time)/100.0;
float A = principal+si;
float B = A/(time*12.0);
printf("==================== BANK LOAN SUMMARY =====================\n");
printf("Principal Amount: PKR %.2f \n" , principal);
printf("Annual Interest Rate:  %.2f%c  \n" , rate,x);
printf("Loan Duration: %d Years \n" , time);
printf("-------------------------------------------------------------\n");
printf("Total Accrued Interest: %.2f \n" , si);
printf("Total Payable Amount: %.2f \n" , A);
printf("Monthly Installment: %.2f \n" , B);
printf("=================================================================");
return 0;
}  