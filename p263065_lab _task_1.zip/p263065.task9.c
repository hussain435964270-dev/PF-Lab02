#include <stdio.h>
int main(){
double basic_salary = 85000.00;
float A = 0.20*basic_salary;
float B = 0.10*basic_salary;
float C = basic_salary+A+B;
float D = 0.05*C;
float E = C-D;
printf("========================= MONTHLY SALARY SLIP =======================\n");
printf("Basic Salary: PKR %.2f \n" , basic_salary);
printf("House Rent Allowance: PKR %.2f \n" , A);
printf("Medical Allowance: PKR %.2f \n" , B);
printf("------------------------------------------------------------------------\n");
printf("Gross Salary: PKR %.2f \n" , C);
printf("Tax Deduction: PKR %.2f  \n" , D);
printf("--------------------------------------------------------------------------\n");
printf("Net Payable Salary: PKR %.2f  \n" , E);
printf("============================================================================");
return 0;
}